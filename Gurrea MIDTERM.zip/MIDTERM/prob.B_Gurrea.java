function{
	<input type="text" name="display" id="display" disabled>
					<br>
}